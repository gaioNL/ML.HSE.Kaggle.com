import time
import pandas as pd
import seaborn as sns
import numpy as np
from itertools import product
from sklearn import model_selection
import scipy.sparse
from tqdm import tqdm
import gc
from preprocess_data import downcast_dtypes, train_val_test_split, load_processed_data_from_file, prepare_data 
import lightgbm as lgb
from sklearn.linear_model import LinearRegression
from sklearn.metrics import r2_score, mean_squared_error
import matplotlib.pyplot as plt

def write_predictions(final_preds):
    ''' Write down final predictions in the desired format '''
    df_res = pd.DataFrame(final_preds)
    df_res = df_res.rename(index=str, columns={0: "item_cnt_month"})
    df_res.index.names = ['ID']
    df_res.to_csv('../data/final_preds.csv')
    df_res.to_csv('../data/final_preds.csv.gz', compression='gzip')

if __name__== "__main__":

    load_preprocessed_from_file=False
    if load_preprocessed_from_file:
        filename='../data/processed_merged_data.csv.gz'
        merged_data  = load_processed_data_from_file(filename)
    else:
        merged_data, index_cols, feature_cols = prepare_data(subset=False, write=False)

    ## Train, validation and test split
    # Test set is last month, validation set is the one before,
    # and test set is the rest
    print("Split & clip data...")
    start = time.clock()
    x_train, y_train, x_val, y_val, x_test, y_test = train_val_test_split(merged_data)

    dates = merged_data['date_block_num']
    test_block = dates.max()
    val_block = test_block - 1
    dates_train = dates[dates <  val_block]
    dates_val  = dates[dates == val_block]
    dates_test  = dates[dates == test_block]
    
    # Clip target [0, 20]
    y_train = np.clip(y_train, 0, 20)
    y_val = np.clip(y_val, 0, 20)
    print(">> Done in", time.clock() - start)

    # First model: Linear Reg
    # - Fit a linear regression model to the train set
    # - Look at the performance of this model on the train and val sets
    # - Make predictions for the three sets (train, val, test). They 
    #   will be used as meta features for the second level of stacking
    print("Fit linear reg...")
    lr = LinearRegression(normalize=False)
    lr.fit(x_train.values, y_train)
    
    train_pred_lr = lr.predict(x_train.values)
    train_pred_lr = np.clip(train_pred_lr, 0, 20)
    
    val_pred_lr = lr.predict(x_val.values)
    val_pred_lr = np.clip(val_pred_lr, 0, 20)
    
    test_pred_lr = lr.predict(x_test.values)
    test_pred_lr = np.clip(test_pred_lr, 0, 20)
    
    print('TRAIN: Test R-squared for linreg is %f' % r2_score(y_train, train_pred_lr))
    print('TRAIN: Test RMSE for linreg is %f' % np.sqrt(mean_squared_error(y_train, train_pred_lr)))
    
    print('VAL: Test R-squared for linreg is %f' % r2_score(y_val, val_pred_lr))
    print('VAL: Test RMSE for linreg is %f' % np.sqrt(mean_squared_error(y_val, val_pred_lr)))
    
    # Second model: Light GBM
    # - Fit a lightGBM model to the train set. A set of fixed parameters is used,
    #   no hyperparameter optimization yet. Early stopping is used by looking at
    #   the scores on both the train set and the validation set.
    # - Look at the performance of this model on the train and val sets
    # - Make predictions for the three sets (train, val, test). They 
    #   will be used as meta features for the second level of stacking
    print("Fit lgbm trees...")
    lgb_params = {
                   'feature_fraction': 0.75,
                   'metric': 'rmse',
                   'nthread':1, 
                   'min_data_in_leaf': 2**7, 
                   'bagging_fraction': 0.75, 
                   'learning_rate': 0.03, 
                   'objective': 'mse', 
                   'bagging_seed': 2**7, 
                   'num_leaves': 2**7,
                   'bagging_freq':1,
                   'verbose':0 
                  }
    lgb_res = {}
    model = lgb.train(lgb_params, 
                      train_set=lgb.Dataset(x_train, label=y_train), 
                      num_boost_round=500,
                      valid_sets=[lgb.Dataset(x_train, label=y_train), lgb.Dataset(x_val, label=y_val)] ,
                      valid_names=['train', 'val'],
                      evals_result=lgb_res,
                      verbose_eval=5,
                      early_stopping_rounds=2)
    
    train_pred_lgb = model.predict(x_train)
    train_pred_lgb = np.clip(train_pred_lgb, 0, 20)
    val_pred_lgb = model.predict(x_val)
    val_pred_lgb = np.clip(val_pred_lgb, 0, 20)
    test_pred_lgb = model.predict(x_test)
    test_pred_lgb = np.clip(test_pred_lgb, 0, 20)
    
    print('TRAIN Test R-squared for LightGBM is %f' % r2_score(y_train, train_pred_lgb))
    print('TRAIN Test RMSE for LightGBM is %f' % np.sqrt(mean_squared_error(y_train, train_pred_lgb)))
    
    print('VAL Test R-squared for LightGBM is %f' % r2_score(y_val, val_pred_lgb))
    print('VAL Test RMSE for LightGBM is %f' % np.sqrt(mean_squared_error(y_val, val_pred_lgb)))
    
    ## Meta model
    # Meta features for validation
    # Predictions from first level of models are the features for the second level
    # for the validation and test sets
    print("Build meta features...")
    x_val_level2 = np.c_[val_pred_lr, val_pred_lgb] 
    x_test_level2 = np.c_[test_pred_lr, test_pred_lgb]
    
    # For the training set, instead of using the predictions of the first level
    # of model as is, a validation method is used. The first level of models are
    # trained over a period T, and used to predict on period T+1 to get meta
    # features for the period T+1. This is extended by training the models
    # on the period T+1, and predicting on T+2 to get meta features of T+2. This
    # process is carried over a subset of the whole training period, what I call
    # here the meta period.
    n_months = 6
    meta_period = list(range(val_block - n_months, val_block))
    # Get the target of the second level over the meta period
    dates_train_level2 = dates_train[dates_train.isin(meta_period)]
    y_train_level2 = y_train[dates_train.isin(meta_period)]
    y_train_level2 = np.clip(y_train_level2, 0, 20)
    # Init level2 train features with zero over the meta_period
    x_train_level2 = np.zeros([y_train_level2.shape[0], 2])
    x_train_level2.shape
    
    # Now fill `X_train_level2` with metafeatures over the meta period
    all_lgb_res = {}
    for cur_block_num in tqdm(meta_period):
        # Split locally to get the train and test set. Here the test set is also the validation set
        x_train_local = merged_data.loc[dates <  cur_block_num].drop('target', axis=1) 
        y_train_local = merged_data.loc[dates <  cur_block_num, 'target'].values
        y_train_local = np.clip(y_train_local, 0, 20)
        
        x_test_local =  merged_data.loc[dates == cur_block_num].drop('target', axis=1)
        y_test_local =  merged_data.loc[dates == cur_block_num, 'target'].values
        y_test_local = np.clip(y_test_local, 0, 20)

        # Fit a simple regression model
        lr.fit(x_train_local.values, y_train_local)
        pred_lr = lr.predict(x_test_local.values)
        pred_lr = np.clip(pred_lr, 0, 20)

        # Fit a lgbm tree with early stopping, using validation set as current month
        model = lgb.train(lgb_params, 
                      train_set=lgb.Dataset(x_train_local, label=y_train_local), 
                      num_boost_round=500,
                      valid_sets=[lgb.Dataset(x_train_local, label=y_train_local), lgb.Dataset(x_test_local, label=y_test_local)],
                      valid_names=['train', 'val'],
                      evals_result=lgb_res,
                      verbose_eval=10,
                      early_stopping_rounds=2)
        
        all_lgb_res[cur_block_num]=lgb_res
        
        pred_lgb = model.predict(x_test_local)
        pred_lgb = np.clip(pred_lgb, 0, 20)
        # Fill in the meta veatures for current time block
        x_train_level2[dates_train_level2 == cur_block_num] = np.c_[pred_lr, pred_lgb] 
    
    # Training of second level
    # A simple stacking with linear regression is fitted.
    print("Train stacked model linear regression...")
    stack_lr = LinearRegression(normalize=False)
    stack_lr.fit(x_train_level2, y_train_level2)
    
    # Predictions are made over the train and validation set to
    # look at the model performance
    stacked_train_preds = stack_lr.predict(x_train_level2) 
    stacked_train_preds = np.clip(stacked_train_preds, 0, 20)
    stacked_val_preds = stack_lr.predict(x_val_level2)
    stacked_val_preds = np.clip(stacked_val_preds, 0, 20)
    
    # Stacked model performance is compared over each feature performance over the 
    # train and validation set
    print('TRA R-squared for LR is %f' % r2_score(y_train_level2, x_train_level2[:, 0]))
    print('TRA RMSE for      LR is %f' % np.sqrt(mean_squared_error(y_train_level2, x_train_level2[:, 0])))
    print('TRA R-squared for LGBM is %f' % r2_score(y_train_level2, x_train_level2[:, 1]))
    print('TRA RMSE for      LGBM is %f' % np.sqrt(mean_squared_error(y_train_level2, x_train_level2[:, 1])))
    print('VAL R-squared for LR is %f' % r2_score(y_val, x_val_level2[:, 0]))
    print('VAL RMSE for      LR is %f' % np.sqrt(mean_squared_error(y_val, x_val_level2[:, 0])))
    print('VAL R-squared for LGBM is %f' % r2_score(y_val, x_val_level2[:, 1]))
    print('VAL RMSE for      LGBM is %f' % np.sqrt(mean_squared_error(y_val, x_val_level2[:, 1])))
    
    print('TRAIN R-squared for stacking is %f' % r2_score(y_train_level2, stacked_train_preds))
    print('TRAIN RMSE for stacking is %f' % np.sqrt(mean_squared_error(y_train_level2, stacked_train_preds)))
    print('VAL R-squared for stacking is %f' % r2_score(y_val, stacked_val_preds))
    print('VAL RMSE for stacking is %f' % np.sqrt(mean_squared_error(y_val, stacked_val_preds)))
    
    # Get Prediction for test set
    print("Get predictions for test set...")
    final_preds = stack_lr.predict(x_test_level2)
    final_preds = np.clip(final_preds, 0, 20)

    # Write predictions
    write_predictions(final_preds)
