# coding: utf-8
import time
import pandas as pd
import seaborn as sns
import numpy as np
from itertools import product
from sklearn import model_selection
import scipy.sparse
from tqdm import tqdm
import gc

def downcast_dtypes(df):
    '''
        Changes column types in the dataframe: 
                
                `float64` type to `float16`
                `int64`   type to `int16`

        Half precision
    '''
    
    # Select columns to downcast
    float_cols = [c for c in df if df[c].dtype == "float64"]
    int_cols =   [c for c in df if df[c].dtype == "int64"]
    
    # Downcast
    df[float_cols] = df[float_cols].astype(np.float16)
    df[int_cols]   = df[int_cols].astype(np.int16)
    
    return df

def prepare_train_data(train, items, methods=['sum', 'mean', 'std']):
    ''' 
    Create a grid of (shop, item) pairs for train data and add the target data and derived versions of it.
    '''
    # For every month we create a grid from all shops/items combinations from that month
    grid = [] 
    for block_num in train['date_block_num'].unique():
        cur_shops = train[train['date_block_num']==block_num]['shop_id'].unique()
        cur_items = train[train['date_block_num']==block_num]['item_id'].unique()
        grid.append(np.array(list(product(*[cur_shops, cur_items, [block_num]])),dtype='int32'))
    
    #turn the grid into pandas dataframe
    index_cols = ['shop_id', 'item_id', 'date_block_num']
    grid = pd.DataFrame(np.vstack(grid), columns = index_cols,dtype=np.int32)

    # Add the category id
    train = pd.merge(train, items[['item_id', 'item_category_id']] ,how='left',on='item_id')
    grid = pd.merge(grid, items[['item_id', 'item_category_id']] ,how='left',on='item_id')
    
    all_data = grid
    groups = [['item_id'], ['item_category_id'], ['shop_id'], ['shop_id', 'item_id'], ['shop_id', 'item_category_id']]
    for group in tqdm(groups):
        group_name = str('_'.join(group))
        column_names = [ method + '-' + group_name for method in methods]
        groupby = group + ['date_block_num']
        gb = train.groupby(groupby, as_index=False)['item_cnt_day'].agg(methods)
        gb.columns = column_names
        gb = gb.reset_index()
        all_data = pd.merge(all_data, gb, how='left', on=groupby).fillna(0)
    
    # Rename the target 
    all_data = all_data.rename(columns = {'sum-shop_id_item_id':'target'})

    # Keep track of index columns and target columns that we just created
    index_cols = ['shop_id', 'item_id', 'item_category_id', 'date_block_num']
    target_cols = list(all_data.columns.difference(index_cols)) 

    #sort the data
    all_data.sort_values(['date_block_num','shop_id','item_category_id','item_id'],inplace=True)

    return all_data, index_cols, target_cols

def add_test_data(train, test, items):

    # We need now to add the test data at the bottom, with the appropriate date_block_num, and NaN values for the target and its derivatives, because we dont know them.
    last_month_train = train['date_block_num'].max()
    test['date_block_num'] = last_month_train + 1

    # Add the category id
    test = pd.merge(test, items[['item_id', 'item_category_id']] ,how='left',on='item_id')

    merged_data = train.append(test, ignore_index=True).drop('ID', axis=1)

    return merged_data

def add_lagged_data(merged_data, index_cols, target_cols, shift_range = [1, 2, 3, 4, 5, 12]):

    for month_shift in tqdm(shift_range):
        train_shift = merged_data[index_cols + target_cols].copy()
        
        train_shift['date_block_num'] = train_shift['date_block_num'] + month_shift
        
        foo = lambda x: '{}_lag_{}'.format(x, month_shift) if x in target_cols else x
        train_shift = train_shift.rename(columns=foo)
    
        merged_data = pd.merge(merged_data, train_shift, on=index_cols, how='left').fillna(0)
    
    # List of all lagged features
    fit_cols = [col for col in merged_data.columns if col[-1] in [str(item) for item in shift_range]] 
    # Drop all derived non lagged target features but keep target
    to_drop_cols = list(set(list(merged_data.columns)) - (set(fit_cols)|set(index_cols + ['target'])))
    merged_data = merged_data.drop(to_drop_cols, axis=1) 

    # Drop data from first year that doesnt have all the lagged infos
    merged_data = merged_data[merged_data['date_block_num'] >= 12] 

    return merged_data, fit_cols

def train_val_test_split(merged_data):
    dates = merged_data['date_block_num']
    last_month = merged_data['date_block_num'].max()
    dates_train = dates[dates <  last_month - 1]
    dates_val = dates[dates == last_month - 1]
    dates_test  = dates[dates == last_month]
    
    x_train = merged_data.loc[dates <  last_month - 1].drop('target', axis=1)
    x_val = merged_data.loc[dates ==  last_month - 1].drop('target', axis=1)
    x_test = merged_data.loc[dates ==  last_month].drop('target', axis=1)
    
    y_train = merged_data.loc[dates <  last_month - 1, 'target'].values
    y_val = merged_data.loc[dates == last_month - 1, 'target'].values
    y_test = merged_data.loc[dates == last_month, 'target'].values
   
    return x_train, y_train, x_val, y_val, x_test, y_test

def prepare_data(write=True, subset=False):
    # Load data
    print("Loading original data...")
    start = time.clock()
    train = pd.read_csv('../data/sales_train.csv.gz')
    test = pd.read_csv('../data/test.csv.gz')
    shops = pd.read_csv('../data/shops.csv')
    items = pd.read_csv('../data/items.csv')
    item_cats = pd.read_csv('../data/item_categories.csv')
    print(">> Done in", time.clock() - start)

    # Subset for speed
    if subset:
        # Subset of shops
        train = train[train['shop_id'].isin([26, 27, 28])]
        test = test[test['shop_id'].isin([26, 27, 28])]
    
    # Aggregate data
    print("Aggregate data...")
    start = time.clock()
    merged_data, index_cols, target_cols = prepare_train_data(train, items, methods=['sum', 'mean', 'std'])
    merged_data = add_test_data(merged_data, test, items)
    print(">> Done in", time.clock() - start)
    print("  > Index cols:", index_cols)
    print("  > Target cols:", target_cols)

    usage_mb = merged_data.memory_usage(deep=True).sum()
    print("Memory usage: {:03.2f} MB".format(usage_mb/ 1024 ** 2 ))
    print("> Downcast")
    merged_data = downcast_dtypes(merged_data)
    usage_mb = merged_data.memory_usage(deep=True).sum()
    print("Memory usage: {:03.2f} MB".format(usage_mb/ 1024 ** 2 ))
    
    # Lag data > feature columns
    print("Lag data...")
    start = time.clock()
    merged_data, feature_cols = add_lagged_data(merged_data, index_cols, target_cols, shift_range=[1, 2, 3, 4, 5, 12])
    print(">> Done in", time.clock() - start)
    print("  > Feature cols:", feature_cols)

    usage_mb = merged_data.memory_usage(deep=True).sum()
    print("Memory usage: {:03.2f} MB".format(usage_mb/ 1024 ** 2 ))
    print("> Downcast")
    merged_data = downcast_dtypes(merged_data)
    usage_mb = merged_data.memory_usage(deep=True).sum()
    print("Memory usage: {:03.2f} MB".format(usage_mb/ 1024 ** 2 ))
    
    if write:
        # Dump to disk
        print("Save data...")
        start = time.clock()
        if not subset:
            merged_data.to_csv('../data/processed_merged_data.csv.gz', compression='gzip', chunksize=1e5, index=False)
        else:
            merged_data.to_csv('../data/subset_processed_merged_data.csv.gz', compression='gzip', chunksize=1e5, index=False)
        print(">> Done in", time.clock() - start)

    return merged_data, index_cols, feature_cols

def load_processed_data_from_file(filename):
    '''
    Load the preprocess merged data with lagged features from a file.
    Downcast the types to limit memory usage.
    '''
    # Load data from file:
    print("Load data...")
    start = time.clock()
    # Sample 100 rows of data to determine dtypes
    # Impose half precision
    merged_data = pd.read_csv(filename, nrows=100)
    float_cols = [c for c in merged_data if merged_data[c].dtype == "float64"]
    type_dict = {c: np.float16 for c in float_cols}
    int_cols = [c for c in merged_data if merged_data[c].dtype == "int64"]
    type_dict.update({c: np.int16 for c in int_cols})
    
    merged_data = pd.read_csv(filename, dtype=type_dict)
    print(">> Done in", time.clock() - start)
    
    # Look at the RAM usage
    usage_mb = merged_data.memory_usage(deep=True).sum()
    print("Memory usage: {:03.2f} MB".format(usage_mb/ 1024 ** 2 ))

    return merged_data

if __name__== "__main__":

    merged_data, index_cols, feature_cols = prepare_data(subset=True, write=True)
 
    # ## Train, validation and test split
    print("Split data...")
    start = time.clock()
    x_train, y_train, x_val, y_val, x_test, y_test = train_val_test_split(merged_data)
    print(">> Done in", time.clock() - start)
